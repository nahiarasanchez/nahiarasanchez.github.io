var testigo = window.prompt("¿Tienes el móvil?"); // si, no 

  

if(testigo=="si"){ 

document.write("enséñame las pruebas"); 

}else if(testigo=="no"){ 

document.write("Te lo revisaré"); 

}
else{ 

document.write("no mienta por favor"); 

} 