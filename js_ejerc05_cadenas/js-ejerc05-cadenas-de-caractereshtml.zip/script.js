var nombre= "Nahiara";
var apellidos= "Sánchez García";
var primera_letra= nombre[0];

document.write("<p> Las variables nombre y apellidos concatenadas resultan en: ",nombre," ",apellidos," </p>");

document.write("<p> La primera letra de mi nombre es: ",primera_letra,"</p>");

